#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include <fsal.h>
#include "doctest.h"


TEST_CASE("Filepath normalization")
{
		CHECK(fsal::NormalizePath("./test_folder/folder_inside/../folder_inside/./") == "test_folder/folder_inside/");
		CHECK(fsal::NormalizePath("test_folder/folder_inside/../folder_inside/") == "test_folder/folder_inside/");
		CHECK(fsal::NormalizePath("test_folder/../test_folder/./folder_inside/../folder_inside/") == "test_folder/folder_inside/");
		CHECK(fsal::NormalizePath("test_folder/folder_inside/../folder_inside/.") == "test_folder/folder_inside");
}

TEST_CASE("Filepaths")
{

	LOGI("--------------------------------------------------------------------------");
	LOGI("RoamingAppData: %s", GetSystemPath(Location::RoamingAppData).string().c_str());
	LOGI("LocalAppData: %s", GetSystemPath(Location::LocalAppData).string().c_str());
	LOGI("UserPictures: %s", GetSystemPath(Location::UserPictures).string().c_str());
	LOGI("UserVideos: %s", GetSystemPath(Location::UserVideos).string().c_str());
	LOGI("ProgramData: %s", GetSystemPath(Location::ProgramData).string().c_str());
	LOGI("ProgramFiles: %s", GetSystemPath(Location::ProgramFiles).string().c_str());
	LOGI("Temp: %s", GetSystemPath(Location::Temp).string().c_str());
	LOGI("--------------------------------------------------------------------------");
}

TEST_CASE("testing the factorial function")
{
	fsal::FileSystem fs;
	fs.PushSearchPath("../");

	{
		fsal::File f = fs.Open(fsal::Location("test.txt", fsal::Location::kCurrentDirectory), fsal::kWrite);
		CHECK(f);
		f << std::string("asdasdasd");
	}
	{
		fsal::File f = fs.Open(fsal::Location("test.txt", fsal::Location::kCurrentDirectory), fsal::kRead);
		CHECK(f);
		std::string str;
		f >> str;
		CHECK(str == std::string("asdasdasd"));
	}
	{
		fsal::ZipReader zip;
		auto zipfile = fs.Open("test_archive.zip");
		CHECK(zipfile);

		fsal::Status r = zip.OpenArchive(zipfile);
		CHECK(r.ok());

		auto file = zip.OpenFile("test_folder/folder_inside/../folder_inside/./test_file.txt");
		CHECK(file);

		std::string str = file;
		CHECK(str == "test");

		auto l1 = zip.ListDirectory("./test_folder/folder_inside/../folder_inside/./");
		for (const auto& l: l1)
		{
			printf("%s\n", l.c_str());
		}
	}
}
